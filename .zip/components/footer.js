function FooterComp() {
    return (<>
        < p className="copyrightText" >Copyright © 2022 Sustainable Procurement, Environmental Social Standards Enhancement (SPESSE)</p>
    </>);
}

export default FooterComp;